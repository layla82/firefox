document.addEventListener('DOMContentLoaded', function() {
  document.getElementById("checkbox1").addEventListener("click", handler);
});

// The handler also must go in a .js file
function handler() {
  if(document.getElementById('checkbox1').checked==true){
	  document.location.href="switch.html"
  }
  else{
	  document.location.href="popup.html"
  }
}


chrome.tabs.query({currentWindow: true, active: true}, function(tabs){
    var myurl = tabs[0].url;
    const myObj = {
      name: myurl,
    };
    const myObjStr = JSON.stringify(myObj);

console.log(myObjStr);
    $.ajax({
      type: "POST",
      url: "http://127.0.0.1:5000/url",
      data : myObjStr,
      success: function(data) {
          alertify.alert(data)
		  if (data == "added and blocked"){
			  console.log(data)
      chrome.webRequest.onBeforeRequest.addListener(
        function(details) {
          return {cancel: details.url.indexOf(myurl) != -1};
        },
        {urls: ["<all_urls>"]},
        ["blocking"]);
		  }
      },
      error: function(e) {
          alertify.alert("It doesnot work")
      }
  });

});