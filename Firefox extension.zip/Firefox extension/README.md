
# GmailJS Node boilerplate

This repo contains sample code to get a WebExtensions-based
browser-extension using
the [gmail.js](https://github.com/KartikTalwar/gmail.js/) library.

## Usage

First get the code and build it:

````
1) Clone this repo
2) Load the extension
3) open your gmail and check your console
4) once it displays message "hey! this is your extension speaking", now open an email page and it should fetch the email_data
````
Cheers!
# gmail-extension
# gmail-extension
