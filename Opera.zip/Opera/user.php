
<?php
$user = $_GET['user'];
$password = $_GET['pass'];
$conn= mysqli_connect('localhost','root','','test');
if(!$conn) {echo "Unable to Connect to the dataBase"; }
$query="INSERT INTO `test`.`users` ( `User-Email`, `User-Password`)
 VALUES ('$user', '$password' )"; 
  mysqli_query($connection,$query);
?>
<?php
// Fetching Values From URL
$name2 = $_POST['name1'];
$password2 = $_POST['password1'];
$connection = mysql_connect("localhost", "root", ""); // Establishing Connection with Server..
$db = mysql_select_db("test", $connection); // Selecting Database
if (isset($_POST['name1'])) {
$query = mysql_query("insert into form_element(User-Email, User-Password) values ('$name2', '$password2')"); //Insert Query
echo "Form Submitted succesfully";
}
mysql_close($connection); // Connection Closed
?>